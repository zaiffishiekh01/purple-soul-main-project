import { Router } from "express";
import vendorAuthController from "../../controllers/authController/vendorAuthController.js";
import vendorController from "../../controllers/vendorController/vendorController.js";
import authMiddleware from "../../middleware/authMiddleware.js";
import fileUploader from "../../middleware/multerMiddleware.js";
import { validateDataMiddleware } from "../../middleware/validateMiddleware.js";
import { userLoginSchema, vendorRegistrationSchema } from "../../validations/zod.js";

export const vendorPublicRouter: Router = Router();
// vendor
vendorPublicRouter.route(`/vendor-register/:id?`).post(validateDataMiddleware(vendorRegistrationSchema), fileUploader, vendorAuthController.register);
vendorPublicRouter.route(`/vendor-login`).post(validateDataMiddleware(userLoginSchema), vendorAuthController.login);
vendorPublicRouter.route(`/vendor/:id`).post(authMiddleware.checkToken, vendorController.getVendorById);
