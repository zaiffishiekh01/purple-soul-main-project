import { useState } from 'react';
import { Shield, Plus, Edit, Trash2, X, Check, UserPlus, CheckCircle, XCircle } from 'lucide-react';
import { useAdminManagement, AdminPermissions } from '../../hooks/useAdminPermissions';

interface CreateAdminModalProps {
  onClose: () => void;
  onCreate: (email: string, password: string, roleName: string, permissions: Partial<AdminPermissions>) => Promise<void>;
}

function CreateAdminModal({ onClose, onCreate }: CreateAdminModalProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [roleName, setRoleName] = useState('');
  const [permissions, setPermissions] = useState({
    vendor_management: false,
    order_management: false,
    product_management: false,
    finance_management: false,
    analytics_monitoring: false,
  });
  const [loading, setLoading] = useState(false);

  const permissionLabels = {
    vendor_management: 'Vendor Management',
    order_management: 'Order Management',
    product_management: 'Product Management',
    finance_management: 'Finance Management',
    analytics_monitoring: 'Analytics Monitoring',
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onCreate(email, password, roleName, permissions);
      onClose();
    } catch (error: any) {
      alert(error.message || 'Failed to create admin. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const toggleAllPermissions = (checked: boolean) => {
    setPermissions({
      vendor_management: checked,
      order_management: checked,
      product_management: checked,
      finance_management: checked,
      analytics_monitoring: checked,
    });
  };

  const allSelected = Object.values(permissions).every(v => v);
  const someSelected = Object.values(permissions).some(v => v) && !allSelected;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <UserPlus className="w-6 h-6 text-emerald-600" />
            Create New Admin
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email Address *
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              placeholder="admin@example.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Password *
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              placeholder="Minimum 6 characters"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Role *
            </label>
            <select
              value={roleName}
              onChange={(e) => setRoleName(e.target.value)}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            >
              <option value="">Select a role...</option>
              <option value="admin">Admin</option>
              <option value="support">Support</option>
              <option value="super_admin">Super Admin</option>
            </select>
            <p className="text-xs text-gray-500 mt-1">
              Admin: Full access except creating admins | Support: Limited support access | Super Admin: Complete platform control
            </p>
          </div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <label className="block text-sm font-medium text-gray-700">
                Permissions *
              </label>
              <button
                type="button"
                onClick={() => toggleAllPermissions(!allSelected)}
                className="text-sm text-emerald-600 hover:text-emerald-700 font-medium"
              >
                {allSelected ? 'Deselect All' : 'Select All'}
              </button>
            </div>

            <div className="space-y-3 bg-gray-50 rounded-lg p-4">
              {Object.entries(permissionLabels).map(([key, label]) => (
                <label key={key} className="flex items-center gap-3 cursor-pointer group">
                  <input
                    type="checkbox"
                    checked={permissions[key as keyof typeof permissions]}
                    onChange={(e) => setPermissions({
                      ...permissions,
                      [key]: e.target.checked,
                    })}
                    className="w-5 h-5 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500"
                  />
                  <span className="text-sm text-gray-700 group-hover:text-gray-900">
                    {label}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-6 py-3 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Creating...' : 'Create Admin'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export function AdminManagement() {
  const { admins, loading, createAdmin, updateAdminRole, deleteAdmin } = useAdminManagement();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<any>(null);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  const handleCreateAdmin = async (email: string, password: string, roleName: string, permissions: any) => {
    try {
      await createAdmin(email, password, roleName, permissions);
      showNotification('success', `Administrator account created successfully for ${email}`);
      setShowCreateModal(false);
    } catch (error: any) {
      throw error;
    }
  };

  const handleDelete = async (admin: any) => {
    if (admin.is_super_admin) {
      showNotification('error', 'Super administrators cannot be deleted for security reasons');
      return;
    }

    const userIdDisplay = admin.user_id.substring(0, 8);
    if (!confirm(`Are you sure you want to delete administrator ${userIdDisplay}? This action cannot be undone.`)) {
      return;
    }

    try {
      await deleteAdmin(admin.id, admin.user_id);
      showNotification('success', 'Administrator account has been successfully removed');
    } catch (error) {
      showNotification('error', 'Failed to delete administrator. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Shield className="w-8 h-8 text-emerald-600" />
            Admin Management
          </h1>
          <p className="text-gray-600 mt-1">Manage admin users and their permissions</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Create Admin
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
          <div className="text-sm text-gray-600">Total Admins</div>
          <div className="text-2xl font-bold text-gray-900 mt-1">{admins.length}</div>
        </div>
        <div className="bg-emerald-50 p-4 rounded-xl shadow-sm border border-emerald-200">
          <div className="text-sm text-emerald-700">Super Admins</div>
          <div className="text-2xl font-bold text-emerald-900 mt-1">
            {admins.filter(a => a.is_super_admin).length}
          </div>
        </div>
        <div className="bg-blue-50 p-4 rounded-xl shadow-sm border border-blue-200">
          <div className="text-sm text-blue-700">Role-Based Admins</div>
          <div className="text-2xl font-bold text-blue-900 mt-1">
            {admins.filter(a => !a.is_super_admin).length}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-4 px-6 font-semibold text-gray-700">Admin</th>
                <th className="text-left py-4 px-6 font-semibold text-gray-700">Role</th>
                <th className="text-left py-4 px-6 font-semibold text-gray-700">Permissions</th>
                <th className="text-left py-4 px-6 font-semibold text-gray-700">Created</th>
                <th className="text-left py-4 px-6 font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {admins.map((admin) => (
                <tr key={admin.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center text-white font-semibold">
                        {admin.user_id.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">{admin.user_id.substring(0, 8)}...</div>
                        {admin.is_super_admin && (
                          <span className="text-xs text-emerald-600 font-medium">Super Admin</span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border ${
                      admin.is_super_admin
                        ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
                        : 'bg-blue-100 text-blue-700 border-blue-200'
                    }`}>
                      {admin.role || 'No Role'}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    {admin.is_super_admin ? (
                      <span className="text-sm text-gray-600">All Permissions</span>
                    ) : admin.permissions ? (
                      <div className="flex flex-wrap gap-1">
                        {Object.entries(admin.permissions)
                          .filter(([key, value]) => key !== 'is_super_admin' && value === true)
                          .map(([key]) => (
                            <span
                              key={key}
                              className="inline-flex items-center px-2 py-1 rounded bg-gray-100 text-xs text-gray-700"
                            >
                              {key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </span>
                          ))}
                      </div>
                    ) : (
                      <span className="text-sm text-gray-400">None</span>
                    )}
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-600">
                      {new Date(admin.created_at).toLocaleDateString()}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2">
                      {!admin.is_super_admin && (
                        <>
                          <button
                            onClick={() => setEditingAdmin(admin)}
                            className="p-2 hover:bg-blue-50 rounded-lg transition-colors text-blue-600"
                            title="Edit Permissions"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(admin)}
                            className="p-2 hover:bg-red-50 rounded-lg transition-colors text-red-600"
                            title="Delete Admin"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {admins.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              No admins found. Create your first admin to get started.
            </div>
          )}
        </div>
      </div>

      {notification && (
        <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-top-2">
          <div className={`flex items-center gap-3 px-6 py-4 rounded-lg shadow-lg ${
            notification.type === 'success'
              ? 'bg-emerald-50 border border-emerald-200'
              : 'bg-red-50 border border-red-200'
          }`}>
            {notification.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
            ) : (
              <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
            )}
            <p className={`text-sm font-medium ${
              notification.type === 'success' ? 'text-emerald-800' : 'text-red-800'
            }`}>
              {notification.message}
            </p>
            <button
              onClick={() => setNotification(null)}
              className={`ml-2 p-1 rounded hover:bg-white/50 transition-colors ${
                notification.type === 'success' ? 'text-emerald-600' : 'text-red-600'
              }`}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {showCreateModal && (
        <CreateAdminModal
          onClose={() => setShowCreateModal(false)}
          onCreate={handleCreateAdmin}
        />
      )}

      {editingAdmin && (
        <EditAdminModal
          admin={editingAdmin}
          onClose={() => setEditingAdmin(null)}
          onUpdate={updateAdminRole}
        />
      )}
    </div>
  );
}

function EditAdminModal({ admin, onClose, onUpdate }: any) {
  const [roleName, setRoleName] = useState(admin.role || '');
  const [permissions, setPermissions] = useState(admin.permissions || {
    vendor_management: false,
    order_management: false,
    product_management: false,
    finance_management: false,
    analytics_monitoring: false,
  });
  const [loading, setLoading] = useState(false);

  const permissionLabels = {
    vendor_management: 'Vendor Management',
    order_management: 'Order Management',
    product_management: 'Product Management',
    finance_management: 'Finance Management',
    analytics_monitoring: 'Analytics Monitoring',
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onUpdate(admin.id, roleName, permissions);
      onClose();
    } catch (error) {
      alert('Failed to update administrator. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Edit Admin Permissions</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email Address
            </label>
            <input
              type="email"
              value={admin.email}
              disabled
              className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Role Name *
            </label>
            <input
              type="text"
              value={roleName}
              onChange={(e) => setRoleName(e.target.value)}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-4">
              Permissions *
            </label>
            <div className="space-y-3 bg-gray-50 rounded-lg p-4">
              {Object.entries(permissionLabels).map(([key, label]) => (
                <label key={key} className="flex items-center gap-3 cursor-pointer group">
                  <input
                    type="checkbox"
                    checked={permissions[key as keyof typeof permissions]}
                    onChange={(e) => setPermissions({
                      ...permissions,
                      [key]: e.target.checked,
                    })}
                    className="w-5 h-5 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500"
                  />
                  <span className="text-sm text-gray-700 group-hover:text-gray-900">
                    {label}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-6 py-3 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors font-medium disabled:opacity-50"
            >
              {loading ? 'Updating...' : 'Update Permissions'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
