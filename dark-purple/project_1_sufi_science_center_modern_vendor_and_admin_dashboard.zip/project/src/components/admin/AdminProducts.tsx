import { useState } from 'react';
import { Package, Search, Filter, Eye, Trash2, AlertCircle, Edit2, X as XIcon, Check } from 'lucide-react';
import { useProducts } from '../../hooks/useProducts';

export function AdminProducts() {
  const { products, loading, updateProduct } = useProducts();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [editingField, setEditingField] = useState<'markup' | 'discount' | null>(null);
  const [adjustmentValue, setAdjustmentValue] = useState<string>('');
  const [adjustmentType, setAdjustmentType] = useState<'amount' | 'percent'>('percent');

  const filteredProducts = products.filter(product => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sku?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || product.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const categories = Array.from(new Set(products.map(p => p.category).filter(Boolean)));

  const stats = {
    total: products.length,
    active: products.filter(p => p.status === 'active').length,
    lowStock: products.filter(p => p.stock_quantity < 10).length,
    outOfStock: products.filter(p => p.stock_quantity === 0).length,
  };

  const calculateFinalPrice = (product: any, markupAmount: number, markupType: string, discountAmount: number, discountType: string) => {
    const cost = product.cost || 0;
    let price = cost;

    if (markupAmount > 0) {
      if (markupType === 'percent') {
        price = cost + (cost * markupAmount / 100);
      } else {
        price = cost + markupAmount;
      }
    }

    if (discountAmount > 0) {
      if (discountType === 'percent') {
        price = price - (price * discountAmount / 100);
      } else {
        price = price - discountAmount;
      }
    }

    return Math.max(0, price);
  };

  const handleAdjustment = async (productId: string, product: any, field: 'markup' | 'discount') => {
    const value = parseFloat(adjustmentValue);
    if (isNaN(value) || value < 0) {
      return;
    }

    const updates: any = {};

    if (field === 'markup') {
      updates.markup_amount = value;
      updates.markup_type = adjustmentType;
    } else {
      updates.discount_amount = value;
      updates.discount_type = adjustmentType;
    }

    const markupAmount = field === 'markup' ? value : (product.markup_amount || 0);
    const markupType = field === 'markup' ? adjustmentType : (product.markup_type || 'percent');
    const discountAmount = field === 'discount' ? value : (product.discount_amount || 0);
    const discountType = field === 'discount' ? adjustmentType : (product.discount_type || 'percent');

    updates.final_price = calculateFinalPrice(product, markupAmount, markupType, discountAmount, discountType);
    updates.price = updates.final_price;

    try {
      await updateProduct(productId, updates);
      setEditingProductId(null);
      setEditingField(null);
      setAdjustmentValue('');
    } catch (error) {
      console.error('Failed to update product:', error);
    }
  };

  const startEditing = (productId: string, field: 'markup' | 'discount') => {
    setEditingProductId(productId);
    setEditingField(field);
    setAdjustmentValue('');
    setAdjustmentType('percent');
  };

  const cancelEditing = () => {
    setEditingProductId(null);
    setEditingField(null);
    setAdjustmentValue('');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Package className="w-8 h-8 text-emerald-600" />
            All Products
          </h1>
          <p className="text-gray-600 mt-1">View and manage all platform products</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
          <div className="text-sm text-gray-600">Total Products</div>
          <div className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</div>
        </div>
        <div className="bg-green-50 p-4 rounded-xl shadow-sm border border-green-200">
          <div className="text-sm text-green-700">Active</div>
          <div className="text-2xl font-bold text-green-900 mt-1">{stats.active}</div>
        </div>
        <div className="bg-yellow-50 p-4 rounded-xl shadow-sm border border-yellow-200">
          <div className="text-sm text-yellow-700">Low Stock</div>
          <div className="text-2xl font-bold text-yellow-900 mt-1">{stats.lowStock}</div>
        </div>
        <div className="bg-red-50 p-4 rounded-xl shadow-sm border border-red-200">
          <div className="text-sm text-red-700">Out of Stock</div>
          <div className="text-2xl font-bold text-red-900 mt-1">{stats.outOfStock}</div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search products by name or SKU..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
          </div>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
          >
            <option value="all">All Categories</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Product</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">SKU</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Category</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Cost</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Markup</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Discount</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Vendor Price</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Commission</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Marketplace Price</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Stock</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.map((product) => (
                <tr key={product.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-3">
                      {product.images?.[0] ? (
                        <img
                          src={product.images[0]}
                          alt={product.name}
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-lg bg-gray-200 flex items-center justify-center">
                          <Package className="w-6 h-6 text-gray-400" />
                        </div>
                      )}
                      <div>
                        <div className="font-medium text-gray-900">{product.name}</div>
                        <div className="text-sm text-gray-600 line-clamp-1">{product.description}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="font-mono text-sm text-gray-600">{product.sku}</div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="text-sm text-gray-700">{product.category}</div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="text-sm text-gray-700">${(product.cost || 0).toFixed(2)}</div>
                  </td>
                  <td className="py-4 px-4">
                    {editingProductId === product.id && editingField === 'markup' ? (
                      <div className="flex items-center gap-1 min-w-[180px]">
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={adjustmentValue}
                          onChange={(e) => setAdjustmentValue(e.target.value)}
                          placeholder="Value"
                          className="w-20 px-2 py-1 text-sm border border-gray-300 rounded"
                          autoFocus
                        />
                        <select
                          value={adjustmentType}
                          onChange={(e) => setAdjustmentType(e.target.value as 'amount' | 'percent')}
                          className="px-2 py-1 text-sm border border-gray-300 rounded"
                        >
                          <option value="percent">%</option>
                          <option value="amount">$</option>
                        </select>
                        <button
                          onClick={() => handleAdjustment(product.id, product, 'markup')}
                          className="p-1 bg-green-600 text-white rounded hover:bg-green-700"
                          title="Apply Markup"
                        >
                          <Check className="w-3 h-3" />
                        </button>
                        <button
                          onClick={cancelEditing}
                          className="p-1 bg-gray-400 text-white rounded hover:bg-gray-500"
                          title="Cancel"
                        >
                          <XIcon className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        {product.markup_amount > 0 ? (
                          <div>
                            <div className="text-sm font-semibold text-green-600">
                              +{product.markup_type === 'percent' ? product.markup_amount + '%' : '$' + product.markup_amount.toFixed(2)}
                            </div>
                          </div>
                        ) : (
                          <div className="text-sm text-gray-400">No markup</div>
                        )}
                        <button
                          onClick={() => startEditing(product.id, 'markup')}
                          className="p-1 hover:bg-gray-100 rounded transition-colors text-gray-600"
                          title="Set Markup"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </td>
                  <td className="py-4 px-4">
                    {editingProductId === product.id && editingField === 'discount' ? (
                      <div className="flex items-center gap-1 min-w-[180px]">
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={adjustmentValue}
                          onChange={(e) => setAdjustmentValue(e.target.value)}
                          placeholder="Value"
                          className="w-20 px-2 py-1 text-sm border border-gray-300 rounded"
                          autoFocus
                        />
                        <select
                          value={adjustmentType}
                          onChange={(e) => setAdjustmentType(e.target.value as 'amount' | 'percent')}
                          className="px-2 py-1 text-sm border border-gray-300 rounded"
                        >
                          <option value="percent">%</option>
                          <option value="amount">$</option>
                        </select>
                        <button
                          onClick={() => handleAdjustment(product.id, product, 'discount')}
                          className="p-1 bg-green-600 text-white rounded hover:bg-green-700"
                          title="Apply Discount"
                        >
                          <Check className="w-3 h-3" />
                        </button>
                        <button
                          onClick={cancelEditing}
                          className="p-1 bg-gray-400 text-white rounded hover:bg-gray-500"
                          title="Cancel"
                        >
                          <XIcon className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        {product.discount_amount > 0 ? (
                          <div>
                            <div className="text-sm font-semibold text-red-600">
                              -{product.discount_type === 'percent' ? product.discount_amount + '%' : '$' + product.discount_amount.toFixed(2)}
                            </div>
                          </div>
                        ) : (
                          <div className="text-sm text-gray-400">No discount</div>
                        )}
                        <button
                          onClick={() => startEditing(product.id, 'discount')}
                          className="p-1 hover:bg-gray-100 rounded transition-colors text-gray-600"
                          title="Set Discount"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </td>
                  <td className="py-4 px-4">
                    <div className="font-semibold text-gray-900">${(product.final_price || product.price || 0).toFixed(2)}</div>
                    <div className="text-xs text-gray-500">Vendor gets</div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="font-semibold text-emerald-600">
                      {product.commission_percentage ? `${product.commission_percentage}%` : '15%'}
                    </div>
                    <div className="text-xs text-gray-500">
                      ${(product.commission_amount || 0).toFixed(2)}
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="font-semibold text-gray-900">
                      ${(product.final_marketplace_price || (product.final_price || product.price || 0)).toFixed(2)}
                    </div>
                    <div className="text-xs text-gray-500">Customer pays</div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      <span className={`font-medium ${
                        product.stock_quantity === 0 ? 'text-red-600' :
                        product.stock_quantity < 10 ? 'text-yellow-600' :
                        'text-gray-900'
                      }`}>
                        {product.stock_quantity}
                      </span>
                      {product.stock_quantity < 10 && product.stock_quantity > 0 && (
                        <AlertCircle className="w-4 h-4 text-yellow-600" />
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border ${
                      product.status === 'active'
                        ? 'bg-green-100 text-green-700 border-green-200'
                        : 'bg-gray-100 text-gray-700 border-gray-200'
                    }`}>
                      {product.status}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <button
                      onClick={() => setSelectedProduct(product)}
                      className="p-2 hover:bg-emerald-50 rounded-lg transition-colors text-emerald-600"
                      title="View Details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              No products found matching your criteria
            </div>
          )}
        </div>
      </div>

      {selectedProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">Product Details</h2>
              <button
                onClick={() => setSelectedProduct(null)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                ×
              </button>
            </div>

            <div className="p-6 space-y-6">
              {selectedProduct.images?.[0] && (
                <img
                  src={selectedProduct.images[0]}
                  alt={selectedProduct.name}
                  className="w-full h-64 object-cover rounded-lg"
                />
              )}

              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Product Information</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Name:</span>
                    <span className="font-medium text-gray-900">{selectedProduct.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">SKU:</span>
                    <span className="font-mono text-gray-900">{selectedProduct.sku}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Category:</span>
                    <span className="font-medium text-gray-900">{selectedProduct.category}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Price:</span>
                    <span className="font-semibold text-gray-900">${selectedProduct.price.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Stock:</span>
                    <span className="font-medium text-gray-900">{selectedProduct.stock_quantity}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border ${
                      selectedProduct.status === 'active'
                        ? 'bg-green-100 text-green-700 border-green-200'
                        : 'bg-gray-100 text-gray-700 border-gray-200'
                    }`}>
                      {selectedProduct.status}
                    </span>
                  </div>
                </div>
              </div>

              {selectedProduct.description && (
                <div className="border-t border-gray-200 pt-6">
                  <h3 className="font-semibold text-gray-900 mb-2">Description</h3>
                  <p className="text-sm text-gray-700">{selectedProduct.description}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
