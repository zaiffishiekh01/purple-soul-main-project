import { useState, useEffect } from 'react';
import { Warehouse, CheckCircle, XCircle, Clock, Eye, MapPin, Calendar, Package, TruckIcon } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { WarehouseRequest, WarehouseRequestStatus } from '../../types';

export default function AdminWarehouse() {
  const [requests, setRequests] = useState<WarehouseRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<WarehouseRequestStatus | 'ALL'>('ALL');
  const [selectedRequest, setSelectedRequest] = useState<WarehouseRequest | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [vendorDetails, setVendorDetails] = useState<Record<string, any>>({});

  useEffect(() => {
    fetchRequests();
  }, [statusFilter]);

  const fetchRequests = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from('warehouse_requests')
        .select('*')
        .order('created_at', { ascending: false });

      if (statusFilter !== 'ALL') {
        query = query.eq('status', statusFilter);
      }

      const { data, error } = await query;

      if (error) throw error;

      setRequests(data || []);

      if (data && data.length > 0) {
        const vendorIds = [...new Set(data.map((r) => r.vendor_id))];
        const { data: vendors } = await supabase
          .from('vendors')
          .select('id, business_name, contact_email, contact_phone')
          .in('id', vendorIds);

        if (vendors) {
          const vendorMap: Record<string, any> = {};
          vendors.forEach((v) => {
            vendorMap[v.id] = v;
          });
          setVendorDetails(vendorMap);
        }
      }
    } catch (error) {
      console.error('Error fetching warehouse requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const openDetailModal = (request: WarehouseRequest) => {
    setSelectedRequest(request);
    setShowDetailModal(true);
  };

  const closeDetailModal = () => {
    setShowDetailModal(false);
    setSelectedRequest(null);
  };

  const getStatusBadge = (status: WarehouseRequestStatus) => {
    switch (status) {
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-yellow-100 text-yellow-700 border border-yellow-200">
            <Clock className="w-3 h-3" />
            Pending
          </span>
        );
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700 border border-green-200">
            <CheckCircle className="w-3 h-3" />
            Approved
          </span>
        );
      case 'active':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-700 border border-blue-200">
            <Warehouse className="w-3 h-3" />
            Active
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-700 border border-red-200">
            <XCircle className="w-3 h-3" />
            Rejected
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-700 border border-gray-200">
            <CheckCircle className="w-3 h-3" />
            Completed
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold bg-gray-100 text-gray-700 border border-gray-200">
            <XCircle className="w-3 h-3" />
            Cancelled
          </span>
        );
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const statusCounts = {
    all: requests.length,
    pending: requests.filter((r) => r.status === 'pending').length,
    approved: requests.filter((r) => r.status === 'approved').length,
    active: requests.filter((r) => r.status === 'active').length,
    completed: requests.filter((r) => r.status === 'completed').length,
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">US Warehouse Requests</h2>
            <p className="text-sm text-gray-600 mt-1">Manage vendor warehouse storage requests (Free storage, vendor pays shipping)</p>
          </div>
        </div>

        <div className="grid grid-cols-5 gap-4 mb-6">
          <button
            onClick={() => setStatusFilter('ALL')}
            className={`p-4 rounded-xl text-left transition-all ${
              statusFilter === 'ALL'
                ? 'bg-blue-50 border-2 border-blue-500'
                : 'bg-gray-50 border border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="text-sm text-gray-600 mb-1">All Requests</div>
            <div className="text-2xl font-bold text-gray-900">{statusCounts.all}</div>
          </button>

          <button
            onClick={() => setStatusFilter('pending')}
            className={`p-4 rounded-xl text-left transition-all ${
              statusFilter === 'pending'
                ? 'bg-yellow-50 border-2 border-yellow-500'
                : 'bg-gray-50 border border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="text-sm text-gray-600 mb-1">Pending</div>
            <div className="text-2xl font-bold text-yellow-600">{statusCounts.pending}</div>
          </button>

          <button
            onClick={() => setStatusFilter('approved')}
            className={`p-4 rounded-xl text-left transition-all ${
              statusFilter === 'approved'
                ? 'bg-green-50 border-2 border-green-500'
                : 'bg-gray-50 border border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="text-sm text-gray-600 mb-1">Approved</div>
            <div className="text-2xl font-bold text-green-600">{statusCounts.approved}</div>
          </button>

          <button
            onClick={() => setStatusFilter('active')}
            className={`p-4 rounded-xl text-left transition-all ${
              statusFilter === 'active'
                ? 'bg-blue-50 border-2 border-blue-500'
                : 'bg-gray-50 border border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="text-sm text-gray-600 mb-1">Active</div>
            <div className="text-2xl font-bold text-blue-600">{statusCounts.active}</div>
          </button>

          <button
            onClick={() => setStatusFilter('completed')}
            className={`p-4 rounded-xl text-left transition-all ${
              statusFilter === 'completed'
                ? 'bg-gray-50 border-2 border-gray-500'
                : 'bg-gray-50 border border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="text-sm text-gray-600 mb-1">Completed</div>
            <div className="text-2xl font-bold text-gray-600">{statusCounts.completed}</div>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Vendor
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Request Type
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Inventory Value
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    SKUs
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Submitted
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {requests.map((request) => {
                  const vendor = vendorDetails[request.vendor_id];
                  return (
                    <tr key={request.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div>
                          <div className="font-semibold text-gray-900">
                            {vendor?.business_name || 'Unknown Vendor'}
                          </div>
                          <div className="text-sm text-gray-600">{vendor?.contact_email}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {request.request_type.replace('_', ' ')}
                      </td>
                      <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                        ${request.expected_inventory_value.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{request.expected_sku_count}</td>
                      <td className="px-6 py-4">{getStatusBadge(request.status)}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{formatDate(request.created_at)}</td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => openDetailModal(request)}
                          className="px-3 py-1 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors text-sm font-medium inline-flex items-center gap-2"
                        >
                          <Eye className="w-4 h-4" />
                          Review
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {requests.length === 0 && (
              <div className="py-12 text-center">
                <Warehouse className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No warehouse requests found</p>
              </div>
            )}
          </div>
        )}
      </div>

      {showDetailModal && selectedRequest && (
        <WarehouseDetailModal
          request={selectedRequest}
          vendor={vendorDetails[selectedRequest.vendor_id]}
          onClose={closeDetailModal}
          onUpdate={fetchRequests}
        />
      )}
    </div>
  );
}

interface WarehouseDetailModalProps {
  request: WarehouseRequest;
  vendor: any;
  onClose: () => void;
  onUpdate: () => void;
}

function WarehouseDetailModal({ request, vendor, onClose, onUpdate }: WarehouseDetailModalProps) {
  const [decision, setDecision] = useState<'approved' | 'rejected' | null>(null);
  const [warehouseAddress, setWarehouseAddress] = useState('DKC\'s SSC Marketplace US Warehouse\n123 Commerce Drive\nAtlanta, GA 30303\nUnited States');
  const [warehouseEmail, setWarehouseEmail] = useState('warehouse@sufiscience.com');
  const [warehousePhone, setWarehousePhone] = useState('+1 (404) 555-0100');
  const [arrivalDeadline, setArrivalDeadline] = useState('');
  const [programEndDate, setProgramEndDate] = useState('');
  const [adminNotes, setAdminNotes] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const twoWeeksFromNow = new Date();
    twoWeeksFromNow.setDate(twoWeeksFromNow.getDate() + 14);
    setArrivalDeadline(twoWeeksFromNow.toISOString().split('T')[0]);

    const monthsFromNow = new Date();
    monthsFromNow.setMonth(monthsFromNow.getMonth() + request.campaign_duration_months);
    setProgramEndDate(monthsFromNow.toISOString().split('T')[0]);
  }, [request]);

  const handleSubmit = async () => {
    setError('');
    setSuccess('');

    if (!decision) {
      setError('Please select a decision');
      return;
    }

    if (decision === 'approved' && (!arrivalDeadline || !programEndDate)) {
      setError('Please set arrival deadline and program end date');
      return;
    }

    if (decision === 'rejected' && !rejectionReason) {
      setError('Please provide a rejection reason');
      return;
    }

    setSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) throw new Error('Not authenticated');

      const { data: adminUser } = await supabase
        .from('admin_users')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      const updates: Partial<WarehouseRequest> = {
        status: decision,
        reviewed_by_admin_id: adminUser?.id || null,
        reviewed_at: new Date().toISOString(),
      };

      if (decision === 'approved') {
        updates.warehouse_address = warehouseAddress;
        updates.warehouse_contact_email = warehouseEmail;
        updates.warehouse_contact_phone = warehousePhone;
        updates.arrival_deadline = arrivalDeadline;
        updates.program_end_date = programEndDate;
        updates.admin_notes = adminNotes || 'Approved for warehouse storage. Storage is FREE. Vendor pays shipping TO warehouse and return shipping.';
      } else {
        updates.rejection_reason = rejectionReason;
      }

      const { error } = await supabase
        .from('warehouse_requests')
        .update(updates)
        .eq('id', request.id);

      if (error) throw error;

      setSuccess('Warehouse request updated successfully');
      setTimeout(() => {
        onUpdate();
        onClose();
      }, 1500);
    } catch (error) {
      console.error('Error updating warehouse request:', error);
      setError('Failed to update request. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const isPending = request.status === 'pending';

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto my-8">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900">Warehouse Request Details</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-400 hover:text-gray-600"
          >
            <span className="text-2xl">×</span>
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <p className="text-sm font-semibold text-blue-900">Cost Model Reminder:</p>
            <ul className="text-sm text-blue-800 mt-2 space-y-1">
              <li>• Storage at US warehouse: <strong>FREE</strong></li>
              <li>• Shipping TO warehouse: <strong>Vendor pays</strong></li>
              <li>• Return shipping FROM warehouse: <strong>Vendor pays</strong></li>
            </ul>
          </div>

          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Vendor Information</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Business Name:</span>
                <p className="font-medium text-gray-900">{vendor?.business_name || 'N/A'}</p>
              </div>
              <div>
                <span className="text-gray-600">Email:</span>
                <p className="font-medium text-gray-900">{vendor?.contact_email || 'N/A'}</p>
              </div>
              <div>
                <span className="text-gray-600">Phone:</span>
                <p className="font-medium text-gray-900">{vendor?.contact_phone || 'N/A'}</p>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Request Details</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Request Type:</span>
                <p className="font-medium text-gray-900">{request.request_type.replace('_', ' ')}</p>
              </div>
              <div>
                <span className="text-gray-600">Campaign Duration:</span>
                <p className="font-medium text-gray-900">{request.campaign_duration_months} months</p>
              </div>
              <div>
                <span className="text-gray-600">Expected Inventory Value:</span>
                <p className="font-medium text-gray-900">${request.expected_inventory_value.toLocaleString()}</p>
              </div>
              <div>
                <span className="text-gray-600">Number of SKUs:</span>
                <p className="font-medium text-gray-900">{request.expected_sku_count}</p>
              </div>
              <div className="col-span-2">
                <span className="text-gray-600">Product Categories:</span>
                <p className="font-medium text-gray-900">{request.product_categories.join(', ')}</p>
              </div>
              {request.estimated_arrival_date && (
                <div>
                  <span className="text-gray-600">Estimated Arrival:</span>
                  <p className="font-medium text-gray-900">{formatDate(request.estimated_arrival_date)}</p>
                </div>
              )}
              <div>
                <span className="text-gray-600">Shipping Acknowledged:</span>
                <p className="font-medium text-gray-900">{request.shipping_acknowledgment ? 'Yes' : 'No'}</p>
              </div>
            </div>
            {request.vendor_notes && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <span className="text-gray-600 block mb-2">Vendor Notes:</span>
                <p className="text-gray-900 bg-white rounded p-3">{request.vendor_notes}</p>
              </div>
            )}
            {request.special_requirements && (
              <div className="mt-4">
                <span className="text-gray-600 block mb-2">Special Requirements:</span>
                <p className="text-gray-900 bg-white rounded p-3">{request.special_requirements}</p>
              </div>
            )}
          </div>

          {isPending && (
            <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-6 space-y-6">
              <h3 className="font-semibold text-gray-900 text-lg">Make Decision</h3>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
                  <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              )}

              {success && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-green-800">{success}</p>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Decision *</label>
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      onClick={() => setDecision('approved')}
                      className={`px-4 py-3 rounded-lg font-medium transition-all ${
                        decision === 'approved'
                          ? 'bg-green-600 text-white'
                          : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-green-600'
                      }`}
                    >
                      <CheckCircle className="w-5 h-5 inline mr-2" />
                      Approve
                    </button>
                    <button
                      onClick={() => setDecision('rejected')}
                      className={`px-4 py-3 rounded-lg font-medium transition-all ${
                        decision === 'rejected'
                          ? 'bg-red-600 text-white'
                          : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-red-600'
                      }`}
                    >
                      <XCircle className="w-5 h-5 inline mr-2" />
                      Reject
                    </button>
                  </div>
                </div>

                {decision === 'approved' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Warehouse Address *</label>
                      <textarea
                        value={warehouseAddress}
                        onChange={(e) => setWarehouseAddress(e.target.value)}
                        rows={4}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Warehouse Email *</label>
                        <input
                          type="email"
                          value={warehouseEmail}
                          onChange={(e) => setWarehouseEmail(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Warehouse Phone *</label>
                        <input
                          type="tel"
                          value={warehousePhone}
                          onChange={(e) => setWarehousePhone(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Arrival Deadline *</label>
                        <input
                          type="date"
                          value={arrivalDeadline}
                          onChange={(e) => setArrivalDeadline(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Program End Date *</label>
                        <input
                          type="date"
                          value={programEndDate}
                          onChange={(e) => setProgramEndDate(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Admin Notes (Optional)</label>
                      <textarea
                        value={adminNotes}
                        onChange={(e) => setAdminNotes(e.target.value)}
                        rows={3}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Additional instructions or notes for the vendor..."
                      />
                    </div>
                  </>
                )}

                {decision === 'rejected' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Rejection Reason *</label>
                    <textarea
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                      rows={4}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Explain why the request was rejected..."
                    />
                  </div>
                )}

                <button
                  onClick={handleSubmit}
                  disabled={submitting || !decision}
                  className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting ? 'Submitting...' : 'Submit Decision'}
                </button>
              </div>
            </div>
          )}

          {!isPending && (
            <div className="bg-gray-50 rounded-xl p-4">
              <h3 className="font-semibold text-gray-900 mb-3">Decision History</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Status:</span>
                  <span className="font-medium text-gray-900">{request.status}</span>
                </div>
                {request.warehouse_address && (
                  <div className="pt-3 border-t border-gray-200">
                    <span className="text-gray-600 block mb-2">Warehouse Address:</span>
                    <p className="text-gray-900 bg-white rounded p-3 whitespace-pre-line">{request.warehouse_address}</p>
                  </div>
                )}
                {request.warehouse_contact_email && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Warehouse Email:</span>
                    <span className="font-medium text-gray-900">{request.warehouse_contact_email}</span>
                  </div>
                )}
                {request.arrival_deadline && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Arrival Deadline:</span>
                    <span className="font-medium text-gray-900">{formatDate(request.arrival_deadline)}</span>
                  </div>
                )}
                {request.program_end_date && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Program End Date:</span>
                    <span className="font-medium text-gray-900">{formatDate(request.program_end_date)}</span>
                  </div>
                )}
                {request.reviewed_at && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Reviewed At:</span>
                    <span className="font-medium text-gray-900">{formatDate(request.reviewed_at)}</span>
                  </div>
                )}
                {request.admin_notes && (
                  <div className="pt-3 border-t border-gray-200">
                    <span className="text-gray-600 block mb-2">Admin Notes:</span>
                    <p className="text-gray-900 bg-white rounded p-3">{request.admin_notes}</p>
                  </div>
                )}
                {request.rejection_reason && (
                  <div className="pt-3 border-t border-gray-200">
                    <span className="text-gray-600 block mb-2">Rejection Reason:</span>
                    <p className="text-gray-900 bg-white rounded p-3">{request.rejection_reason}</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
