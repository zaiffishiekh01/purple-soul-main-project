import { useState, ReactNode, memo, useMemo } from 'react';
import {
  Users,
  Package,
  ShoppingCart,
  DollarSign,
  BarChart3,
  Settings,
  Bell,
  LogOut,
  Shield,
  Menu,
  X,
  UserCog,
  BookOpen,
  FolderTree,
  Truck,
  RotateCcw,
  Tag,
  FileText,
  Warehouse,
  Beaker,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useAdminPermissions } from '../../hooks/useAdminPermissions';

interface AdminDashboardLayoutProps {
  children: ReactNode;
  activeSection: string;
  onSectionChange: (section: string) => void;
  unreadNotifications?: number;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: BarChart3, permission: null },
  { id: 'admins', label: 'Admin Management', icon: UserCog, permission: 'is_super_admin' },
  { id: 'vendors', label: 'Vendors', icon: Users, permission: 'vendor_management' },
  { id: 'customers', label: 'Customers', icon: Users, permission: null },
  { id: 'orders', label: 'All Orders', icon: ShoppingCart, permission: 'order_management' },
  { id: 'products', label: 'All Products', icon: Package, permission: 'product_management' },
  { id: 'inventory', label: 'All Inventory', icon: Package, permission: 'product_management' },
  { id: 'categories', label: 'Categories', icon: FolderTree, permission: 'product_management' },
  { id: 'shipping', label: 'Shipping', icon: Truck, permission: 'order_management' },
  { id: 'returns', label: 'Returns', icon: RotateCcw, permission: 'order_management' },
  { id: 'labels', label: 'Shipping Labels', icon: Tag, permission: 'order_management' },
  { id: 'warehouse', label: 'US Warehouse', icon: Warehouse, permission: 'order_management' },
  { id: 'test-products', label: 'Test New Product Offers', icon: Beaker, permission: 'product_management' },
  { id: 'fee-waivers', label: 'Fee Waivers', icon: FileText, permission: 'finance_management' },
  { id: 'pricing', label: 'Pricing Rules', icon: DollarSign, permission: 'finance_management' },
  { id: 'finance', label: 'Finance', icon: DollarSign, permission: 'finance_management' },
  { id: 'payouts', label: 'Payouts', icon: DollarSign, permission: 'finance_management' },
  { id: 'analytics', label: 'Analytics', icon: BarChart3, permission: 'analytics_monitoring' },
  { id: 'guidelines', label: 'Product Guidelines', icon: BookOpen, permission: null },
  { id: 'settings', label: 'Settings', icon: Settings, permission: null },
];

const AdminDashboardLayoutComponent = ({
  children,
  activeSection,
  onSectionChange,
  unreadNotifications = 0,
}: AdminDashboardLayoutProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { signOut } = useAuth();
  const { permissions, loading: permissionsLoading } = useAdminPermissions();

  const visibleMenuItems = useMemo(() => {
    if (permissionsLoading) {
      return menuItems;
    }
    return menuItems.filter(item => {
      if (!item.permission) return true;
      if (permissions.is_super_admin) return true;
      return permissions[item.permission as keyof typeof permissions] === true;
    });
  }, [permissions, permissionsLoading]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-50">
      <div className="lg:flex">
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <aside
          className={`fixed lg:sticky top-0 h-screen w-72 bg-white/80 backdrop-blur-xl border-r border-gray-200 z-50 transform transition-transform duration-300 lg:translate-x-0 ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="h-full flex flex-col">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 p-2 rounded-xl">
                      <Shield className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h1 className="text-xl font-bold text-slate-800">
                        DKC's SSC Marketplace
                      </h1>
                      <p className="text-xs text-slate-500 italic">Faith Based Big Ecommerce</p>
                    </div>
                  </div>
                  <p className="text-sm text-slate-600 ml-12">Admin Portal</p>
                </div>
                <button
                  onClick={() => setSidebarOpen(false)}
                  className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
              {visibleMenuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSectionChange(item.id);
                      setSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative ${
                      isActive
                        ? 'bg-gradient-to-r from-emerald-500 to-emerald-600 text-white shadow-lg shadow-emerald-500/30'
                        : 'text-gray-700 hover:bg-gray-100 hover:text-emerald-600'
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isActive ? '' : 'group-hover:scale-110'} transition-transform`} />
                    <span className="font-medium text-sm">{item.label}</span>
                  </button>
                );
              })}
            </nav>

            <div className="p-4 border-t border-gray-200 space-y-3">
              <button
                onClick={() => signOut()}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 text-red-600 hover:bg-red-50 group"
              >
                <LogOut className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span className="font-medium text-sm">Sign Out</span>
              </button>

              <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl p-4">
                <p className="text-xs text-emerald-800 font-medium mb-2">Admin Access</p>
                <p className="text-xs text-gray-600 mb-3">
                  You have full platform management capabilities
                </p>
              </div>
            </div>
          </div>
        </aside>

        <main className="flex-1 min-h-screen">
          <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-gray-200">
            <div className="px-6 py-4 flex items-center justify-between">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <Menu className="w-6 h-6" />
              </button>
              <div className="flex-1 lg:flex-none">
                <h2 className="text-xl font-bold text-gray-900 capitalize">
                  {visibleMenuItems.find((item) => item.id === activeSection)?.label || 'Dashboard'}
                </h2>
              </div>
              <div className="flex items-center gap-4">
                <button
                  className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Bell className="w-5 h-5 text-gray-700" />
                  {unreadNotifications > 0 && (
                    <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
                  )}
                </button>
                <button
                  onClick={() => onSectionChange('settings')}
                  className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center text-white font-semibold hover:shadow-lg transition-shadow"
                >
                  A
                </button>
              </div>
            </div>
          </header>

          <div className="p-6">{children}</div>
        </main>
      </div>
    </div>
  );
};

export const AdminDashboardLayout = memo(AdminDashboardLayoutComponent);
