import { Clock, Mail, CheckCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export function PendingApproval() {
  const { signOut } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-50 flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">
        <div className="text-center">
          <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Clock className="w-10 h-10 text-yellow-600" />
          </div>

          <h1 className="text-3xl font-bold text-slate-800 mb-3">
            Account Pending Approval
          </h1>

          <p className="text-slate-600 mb-8 text-lg">
            Your vendor account has been created successfully and is currently under review by our admin team.
          </p>

          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-6 text-left">
            <h2 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-blue-600" />
              What happens next?
            </h2>
            <ul className="space-y-3 text-sm text-slate-600">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 font-bold mt-0.5">1.</span>
                <span>Our admin team will review your account details</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 font-bold mt-0.5">2.</span>
                <span>You'll receive an email notification once approved</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 font-bold mt-0.5">3.</span>
                <span>After approval, you can access your vendor dashboard</span>
              </li>
            </ul>
          </div>

          <div className="bg-slate-50 rounded-xl p-4 mb-6">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Mail className="w-4 h-4" />
              <span>Approval typically takes 1-2 business days</span>
            </div>
          </div>

          <button
            onClick={() => signOut()}
            className="w-full px-6 py-3 bg-slate-200 text-slate-700 rounded-xl hover:bg-slate-300 transition-all font-medium"
          >
            Sign Out
          </button>

          <p className="text-sm text-slate-500 mt-4">
            Need help? Contact support at{' '}
            <a href="mailto:support@sufism.com" className="text-blue-600 hover:underline">
              support@sufism.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
