import { Key, Shield, CreditCard, Bell, Lock } from 'lucide-react';

export function AccountManagement() {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center gap-4 mb-6">
          <div className="p-3 rounded-xl bg-gradient-to-br from-sufi-purple to-sufi-dark">
            <Lock className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">Security Settings</h3>
            <p className="text-sm text-gray-600">Manage your account security and authentication</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-5 border border-gray-200 rounded-xl hover:border-sufi-purple transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <Key className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Change Password</h4>
                  <p className="text-sm text-gray-600 mt-1">Update your account password</p>
                </div>
              </div>
              <button className="px-4 py-2 bg-sufi-light/30 text-sufi-dark rounded-lg hover:bg-sufi-light/50 transition-colors font-medium">
                Update
              </button>
            </div>
          </div>

          <div className="p-5 border border-gray-200 rounded-xl hover:border-sufi-purple transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-green-50 rounded-lg">
                  <Shield className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Two-Factor Authentication</h4>
                  <p className="text-sm text-gray-600 mt-1">Add an extra layer of security</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-sufi-purple/30 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sufi-purple"></div>
              </label>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center gap-4 mb-6">
          <div className="p-3 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600">
            <CreditCard className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">Payment Methods</h3>
            <p className="text-sm text-gray-600">Manage your payout and billing information</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-5 border-2 border-sufi-purple rounded-xl bg-sufi-light/10">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-8 bg-gradient-to-r from-blue-600 to-blue-400 rounded flex items-center justify-center text-white text-xs font-bold">
                  BANK
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Bank Account</p>
                  <p className="text-sm text-gray-600">****1234</p>
                </div>
              </div>
              <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                Primary
              </span>
            </div>
          </div>

          <button className="w-full p-4 border-2 border-dashed border-gray-300 rounded-xl hover:border-sufi-purple hover:bg-sufi-light/10 transition-colors text-gray-600 hover:text-sufi-dark font-medium">
            + Add Payment Method
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center gap-4 mb-6">
          <div className="p-3 rounded-xl bg-gradient-to-br from-orange-500 to-orange-600">
            <Bell className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">Notification Preferences</h3>
            <p className="text-sm text-gray-600">Choose what notifications you want to receive</p>
          </div>
        </div>

        <div className="space-y-4">
          {[
            { label: 'Order Updates', description: 'Get notified about new orders and status changes' },
            { label: 'Low Stock Alerts', description: 'Receive alerts when inventory is running low' },
            { label: 'Payment Notifications', description: 'Updates about payments and payouts' },
            { label: 'Marketing Updates', description: 'News, tips, and product updates' },
          ].map((pref, index) => (
            <div key={index} className="flex items-center justify-between p-4 rounded-xl hover:bg-gray-50">
              <div>
                <p className="font-medium text-gray-900">{pref.label}</p>
                <p className="text-sm text-gray-600 mt-1">{pref.description}</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked={index < 3} className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-sufi-purple/30 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sufi-purple"></div>
              </label>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-red-50 border border-red-200 rounded-2xl p-6">
        <h3 className="text-lg font-bold text-red-900 mb-2">Danger Zone</h3>
        <p className="text-sm text-red-700 mb-4">
          Permanently delete your account and all associated data. This action cannot be undone.
        </p>
        <button className="px-6 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors font-medium">
          Delete Account
        </button>
      </div>
    </div>
  );
}
