import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { Vendor } from '../types';
import { useAuth } from '../contexts/AuthContext';

export function useVendor() {
  const { userId, userEmail } = useAuth();
  const [vendor, setVendor] = useState<Vendor | null>(null);
  const [loading, setLoading] = useState(true);
  const isFetchingRef = useRef(false);
  const userIdRef = useRef(userId);
  const userEmailRef = useRef(userEmail);

  useEffect(() => {
    userIdRef.current = userId;
    userEmailRef.current = userEmail;
  }, [userId, userEmail]);

  useEffect(() => {
    if (isFetchingRef.current) return;

    const fetchVendor = async () => {
      if (!userId) {
        setVendor(null);
        setLoading(false);
        return;
      }

      isFetchingRef.current = true;
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('vendors')
          .select('*')
          .eq('user_id', userId)
          .maybeSingle();

        if (error) throw error;

        if (!data) {
          const newVendor = {
            user_id: userId,
            business_name: 'New Vendor',
            contact_email: userEmailRef.current || '',
            status: 'active',
          };

          const { data: created, error: createError } = await supabase
            .from('vendors')
            .insert(newVendor)
            .select()
            .single();

          if (createError) throw createError;
          setVendor(created as Vendor);
        } else {
          setVendor(data as Vendor);
        }
      } catch (error) {
        console.error('Error fetching vendor:', error);
      } finally {
        setLoading(false);
        isFetchingRef.current = false;
      }
    };

    fetchVendor();
  }, [userId]);

  const refetch = useCallback(async () => {
    const currentUserId = userIdRef.current;
    if (!currentUserId) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('vendors')
        .select('*')
        .eq('user_id', currentUserId)
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setVendor(data as Vendor);
      }
    } catch (error) {
      console.error('Error refetching vendor:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  const updateVendor = useCallback(async (updates: Partial<Vendor>) => {
    return new Promise<Vendor>((resolve, reject) => {
      setVendor((currentVendor) => {
        if (!currentVendor) {
          reject(new Error('No vendor'));
          return currentVendor;
        }

        supabase
          .from('vendors')
          .update(updates)
          .eq('id', currentVendor.id)
          .select()
          .single()
          .then(({ data, error }) => {
            if (error) {
              reject(error);
            } else {
              setVendor(data as Vendor);
              resolve(data as Vendor);
            }
          })
          .catch(reject);

        return currentVendor;
      });
    });
  }, []);

  return useMemo(() => ({
    vendor,
    loading,
    updateVendor,
    refetch,
  }), [vendor, loading, updateVendor, refetch]);
}
