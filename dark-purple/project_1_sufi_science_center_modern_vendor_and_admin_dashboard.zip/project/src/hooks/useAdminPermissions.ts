import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export interface AdminPermissions {
  vendor_management: boolean;
  order_management: boolean;
  product_management: boolean;
  finance_management: boolean;
  analytics_monitoring: boolean;
  is_super_admin: boolean;
}

export interface AdminUser {
  id: string;
  user_id: string;
  role: string;
  permissions: AdminPermissions;
  is_super_admin: boolean;
  created_at: string;
}

export function useAdminPermissions() {
  const [permissions, setPermissions] = useState<AdminPermissions>({
    vendor_management: false,
    order_management: false,
    product_management: false,
    finance_management: false,
    analytics_monitoring: false,
    is_super_admin: false,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPermissions();
  }, []);

  const fetchPermissions = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase.rpc('get_admin_permissions', {
        p_user_id: user.id
      });

      if (error) throw error;

      if (data) {
        setPermissions(data as AdminPermissions);
      }
    } catch (error) {
      console.error('Error fetching permissions:', error);
    } finally {
      setLoading(false);
    }
  };

  const hasPermission = (permission: keyof AdminPermissions): boolean => {
    if (permissions.is_super_admin) return true;
    return permissions[permission] === true;
  };

  const hasAnyPermission = (perms: Array<keyof AdminPermissions>): boolean => {
    if (permissions.is_super_admin) return true;
    return perms.some(p => permissions[p] === true);
  };

  return {
    permissions,
    loading,
    hasPermission,
    hasAnyPermission,
    isSuperAdmin: permissions.is_super_admin,
    isAdmin: permissions.is_super_admin || Object.values(permissions).some(p => p === true),
  };
}

export function useAdminManagement() {
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAdmins();
  }, []);

  const fetchAdmins = async () => {
    try {
      const { data: adminUsers, error: adminError } = await supabase
        .from('admin_users')
        .select('*')
        .order('created_at', { ascending: false });

      if (adminError) throw adminError;

      setAdmins(adminUsers as AdminUser[] || []);
    } catch (error) {
      console.error('Error fetching admins:', error);
    } finally {
      setLoading(false);
    }
  };

  const createAdmin = async (email: string, password: string, roleName: string, permissions: Partial<AdminPermissions>) => {
    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-admin`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
          },
          body: JSON.stringify({ email, password, roleName, permissions }),
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create admin');
      }

      await fetchAdmins();
      return { success: true };
    } catch (error: any) {
      console.error('Error creating admin:', error);
      throw error;
    }
  };

  const updateAdminRole = async (adminId: string, roleName: string, permissions: Partial<AdminPermissions>) => {
    try {
      const { error } = await supabase
        .from('admin_users')
        .update({
          role: roleName,
          permissions: {
            vendor_management: permissions.vendor_management || false,
            order_management: permissions.order_management || false,
            product_management: permissions.product_management || false,
            finance_management: permissions.finance_management || false,
            analytics_monitoring: permissions.analytics_monitoring || false,
          },
          is_super_admin: roleName === 'super_admin',
          updated_at: new Date().toISOString(),
        })
        .eq('id', adminId);

      if (error) throw error;

      await fetchAdmins();
    } catch (error) {
      console.error('Error updating admin role:', error);
      throw error;
    }
  };

  const deleteAdmin = async (adminId: string, userId: string) => {
    try {
      // Delete from admin_users table
      const { error: adminError } = await supabase
        .from('admin_users')
        .delete()
        .eq('id', adminId);

      if (adminError) throw adminError;

      // Delete auth user via edge function
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-admin-user`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
          },
          body: JSON.stringify({ userId }),
        }
      );

      if (!response.ok) {
        console.warn('Failed to delete auth user, but admin record deleted');
      }

      await fetchAdmins();
    } catch (error) {
      console.error('Error deleting admin:', error);
      throw error;
    }
  };

  return {
    admins,
    loading,
    createAdmin,
    updateAdminRole,
    deleteAdmin,
    refreshAdmins: fetchAdmins,
  };
}
